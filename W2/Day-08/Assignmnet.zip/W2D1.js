/** @format */

console.log('Problem 1=Print all even numbers in first 50 natural numbers')
for (var a = 1; a <= 50; a++) {
  if (a % 2 == 0) {
    console.log(a)
  }
}

console.log('print all odd numbers in natural numbers from 20 to 50')
for (var b = 21; b <= 50; b += 2) {
  console.log(b)
}
console.log('print all numbers that are divisible by 5')
// 	[12, 45, 67, 89, 90, 34, 35, 55]

const array = [12, 45, 67, 89, 90, 34, 35, 55]
for (var c = 1; c < array.length; c++) {
  if (array[c] % 5 === 0) {
    console.log(array[c])
  }
}

console.log('Print all numbers of this array[[1,2], [3,4], [5,6], [7,8]]')

const arr = [
  [1, 2],
  [3, 4],
  [5, 6],
  [7, 8],
]
for (let d = 0; d < arr.length; d++) {
  console.log(arr[d])
}

;('Print all prime numbers occurring in 1st 50 natural numbers')

let count = 0
let i, j
for (j = 2; j <= 50; j++) {
  for (i = 1; i <= j; i++) {
    if (j % i == 0) count++
  }

  if (count == 2) console.log(j)
  count = 0
}
